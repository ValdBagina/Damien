friends = [ 'rylan' , 'ethan' , 'devin' , 'jaden']
print(friends[0])
print(friends[1])
print(friends[2])
print(friends[3])
