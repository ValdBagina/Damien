message = "hellow python"
print(mesage)
