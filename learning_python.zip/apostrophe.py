message = "One of Python's strength is its diverse community."
print(message)

message = 'One of Python's strength is its diverse community'
