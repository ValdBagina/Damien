message = "hello world!"
print(message)

message = "hello python course world!"
print(message)
