name = "ada lovelace"
print(name.title())

name = "ada lovelace"
print(name.upper())

name = "ada lovelace"
print(name.lower())


first_name = "ada"
last_name = "lovelace"
full_name = first_name + " " + last_name

print(full_name)

print("hello, " + full_name.title() + "!")

message = "hello, " + full_name.title() + "!"
print(message)
