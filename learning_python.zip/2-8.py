print(5+3)
print(4*2)
print(16/2)

favorite_number = 8
message = "My favorite number is " + str(favorite_number)
print(message)
