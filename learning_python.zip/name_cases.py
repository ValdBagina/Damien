name = ("Eric")
message = ("Hello " + name + " would you like some tea?")

print(message)


name = ("raymond")
message = ("Hello " + name.lower() + " " + "how are you")

print(message.title())


first_name = ("Albert")
last_name = ("Einstein")
full_name  = (first_name + " " + last_name)
quote = ('Once said "A person who never made a mistake never tried anything new."')
message = (full_name.title() + " " + quote)

print(message)


famous_person = ('\n\tramond xiang')
message = ("Hello "  +  famous_person +    " How are you?")
print(message)
