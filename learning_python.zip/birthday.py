age = 23
nessage = "Happy " + str(age) + "rd Birthday!"

print(message)
