friends = ['rylan' , 'ethan' , 'devin' , 'jaden']
message = "Hi" + " how are you "

print(message+friends[0].title())
print(message+friends[1].title())
print(message+friends[2].title())
print(message+friends[3].title())
