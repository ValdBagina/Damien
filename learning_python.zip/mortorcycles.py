#how to change an item in the lists

motorcycles = ['honda' , 'yamaha' , 'suzuki']
print(motorcycles)
#original message with list

mortorcycles = ['honda' , 'yamaha' , 'suzuki']

mortorcycles[0] = 'ducati'
print(mortorcycles)

#changed item in list 1st item to duacti


#adding new elements to a list
#simplest way to add new element to a list is to 'append' the item to a list
#when you append an item a new element is added

#E.x

motorcycles = ['honda' , 'yamaha' , 'suzuki']
print(motorcycles)

motorcycles.append('ducati')
print(motorcycles)

#the method append adds 'ducati' to the end of the list wihtout affecting any other elemnent

#append() makes it easy to build a list dynamically for e.x you can start with empty list
#and then add items tot eh list using a series of append()

motorcycle = []

motorcycle.append('honda')
motorcycle.append('ducati')
motorcycle.append('yamaha')
motorcycle.append('suzuki')

print(motorcycle)

#you can add a new element at any position in your list by using the insert()
#method e.x

motorcycle = ['honda' , 'yamaha' , 'suzuki']

motorcycle.insert(0, 'ducati')
print(motorcycle)


#removing things from a list you can do this by using 'del' statment ex

motorcycle = ['honda' , 'yamaha' , 'suzuki']
print(motorcycle)

del motorcycle[1]
print(motorcycle)

#how to remove an item but keep it in a list using pop()

#the pop() method removes the last item in the list but it lets you work with the
#item after removing it

#the term pop comes from thinking of a list as a stack of items and popping one item off
#the top of the stack

motorcycle = ['honda' , 'yamaha' , 'suzuki']
print(motorcycle)

popped_motorcycle = motorcycle.pop()
print(motorcycle)
print(popped_motorcycle)
