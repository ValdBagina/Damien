bicycles = ['trek' , 'cannondale' , 'redline' ,
'specialized']
print(bicycles)

#[' '] In python square brackets indiacate a list and individual elements in the list are
#sepparated by commas

#if you ask pyhton to print list returns its represenation of a list including
#the square brackets


#to access an element in a list write the name of the list folowed
#by the index of the item enclosed in square brackets

#in this example you can pull out the 1st item by

bicycles = ['trek' , 'cannondale' , 'redline' , 'specialized']
print(bicycles[0])

#first item on the list is represented as 1

#you can also use string method on lists e.x


bicycles = ['trek' , 'cannondale' , 'redline' , 'specialized']
print(bicycles[0].title())

#the reason that 0 is represented as 1 is because thats how list is operated
#the second int he list is index 1 and so on
#subtract 1 from its postion in the list

bicycles = ['trek' , 'cannondale' , 'redline' , 'specialized']
print(bicycles[1])
print(bicycles[3])

#python has special syntax for accesing the last eleming in a list by
#asking for the item at index -1. Python alwats returns the last item in the list

bicycles = ['trek' , 'cannondale' , 'redline' , 'specialized']
print(bicycles[-1])

#this will give you 'specialized'
#-1 usefull in list to know because you will want to know the last item in the lists
#without knowing how long it is


#-1 and -2 ect ect extends on
bicycles = ['trek' , 'cannondale' , 'redline' , 'specialized']
print(bicycles[-1])
print(bicycles[-2])
#-2 gives you the second from last and -3 gices you third from


#you can use concenation in here to compose a message

bicycles = ['trek' , 'cannondale' , 'redline' , 'specialized']
message = "My first bicycle was a " + bicycles[0].title() + "."
print(message)
